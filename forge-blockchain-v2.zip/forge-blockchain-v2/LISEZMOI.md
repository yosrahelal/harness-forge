# Pipeline blockchain v2 — Stellar / Soroban et EVM

- `pipeline-blockchain-soroban/` : à copier à la racine d'un projet Soroban (EURxt). 19 agents dont 15 en variante Soroban (Komet, Scout, Sunbeam, OpenZeppelin Stellar Contracts, XDR non signés, multisig à seuils).
- `pipeline-blockchain-evm/` : la même chose pour un projet EVM (Foundry, Halmos, Slither, batch Safe).
- `claude-ai/blockchain-expert/` : pack claude.ai (11 skills .zip + 3 Projets), dont smart-contract-testing et smart-contract-release.

Dans chaque pipeline : remplacer le titre de `docs/00-projet.md`, initialiser git, lire `docs/pipeline.md`, puis demander à l'orchestrateur de lancer l'étape 1 (analyste).
Soroban : `.pipeline/config.json` → renseigner `commands.dry_run`, `commands.storage_check`, `commands.formal` (Sunbeam) ou une dérogation motivée ; `stellar_testnet` reste à `false` sauf décision écrite.

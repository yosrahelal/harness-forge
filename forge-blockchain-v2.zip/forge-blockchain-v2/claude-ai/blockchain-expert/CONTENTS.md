# Expert blockchain — pack claude.ai

_Généré par `node scripts/export-claude-web.js blockchain-expert`._

## Skills (importer chaque `skills/<nom>.zip`)

| Skill | Car. | Description |
|---|---|---|
| `blockchain-project-analysis` | 187 | Analyses a blockchain project (repo, zip, specs) into an evidence-based report on contracts, roles, trust model, value flows, off-chain parts and risks. Use to assess or onboard onto one. |
| `smart-contract-audit` | 197 | Audits smart contracts (Solidity/EVM, Soroban, Anchor) by manual review plus tools when available, and writes a severity-rated audit report. Use for security reviews, pre-audit prep or restitution. |
| `blockchain-architecture` | 193 | Designs or reviews blockchain system architecture (chain, consensus, contracts, upgrades, roles, custody, privacy, IS integration) and records each decision as an ADR. Use for design or review. |
| `tokenization-domain` | 194 | Domain reference for tokenization in regulated finance: stablecoins and deposit tokens, tokenized funds and NAV, RWA standards, chains, custody, EU rules. Use to analyse, design or explain them. |
| `blockchain-docs` | 200 | Writes blockchain deliverables (DAT, ADR, risk register, spec, committee note, executive summary, white paper) in a banking-grade style, as Markdown or Word via the docx skill. Use for such documents. |
| `blockchain-deck` | 193 | Builds blockchain presentations (committee, architecture review, audit restitution, training, pre-sales) as message-first storylines, then the .pptx via the pptx skill. Use for slides or decks. |
| `smart-contract-testing` | 169 | Writes and runs smart-contract tests from the spec: invariants, Halmos or Komet properties, fuzz, fork tests, coverage, mutation score. Use to specify or test contracts. |
| `smart-contract-release` | 189 | Prepares contract deployment, monitoring and upgrades without keys: dry-run, manifest, unsigned Safe batch, role handover, monitor rules, storage-checked upgrades. Use to deploy or upgrade. |
| `council` | 187 | Convenes a four-voice council (own view, Skeptic, Pragmatist, Critic) for ambiguous decisions and go/no-go calls. Use when several valid paths exist and dissent is needed before choosing. |
| `grilling` | 178 | Grills the user relentlessly about a plan, decision or idea, round by round, with a recommended answer per question. Use to stress-test thinking or when the user says 'grill me'. |
| `market-research` | 191 | Conducts market, vendor and technology research with cited sources and a decision-oriented summary. Use for competitor or vendor comparisons, technology scans, due diligence or market sizing. |

## Projets

| Projet | Dossier | Connaissances fournies |
|---|---|---|
| **Expert blockchain** | `projects/expert-blockchain/` | `solidity-smart-contract-engineer.md`, `software-architect.md`, `executive-summary-generator.md` |
| **Audit smart contracts** | `projects/audit-smart-contracts/` | `blockchain-security-auditor.md`, `solidity-smart-contract-engineer.md`, `security-checklist.md` |
| **Architecture blockchain** | `projects/architecture-blockchain/` | `software-architect.md`, `security-architect.md`, `observability-checklist.md` |
